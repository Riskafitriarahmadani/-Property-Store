<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Property Store</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="<?= base_url()?>css/style.css">
    <style>
      body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(120deg, #f6d365, #fda085);
        color: #333;
      }
      .sidebar {
        background: linear-gradient(180deg, #343a40, #6c757d);
        color: #fff;
        min-height: 100vh;
        padding: 15px 10px;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
      }
      .sidebar a {
        color: #ddd;
        text-decoration: none;
        display: block;
        padding: 12px;
        border-radius: 5px;
        transition: all 0.3s;
        font-weight: 500;
      }
      .sidebar a:hover {
        background-color: #495057;
        color: #fff;
      }
      .sidebar .active {
        background-color: #007bff;
        color: #fff;
      }
      .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: linear-gradient(45deg, #007bff, #00d4ff);
        color: #fff;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      }
      .header h2 {
        font-family: "Comic Sans MS", cursive, sans-serif;
      }
      .content {
        background: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s;
      }
      .content:hover {
        transform: scale(1.02);
      }
      .footer {
        background: #343a40;
        color: #fff;
        text-align: center;
        padding: 15px 0;
        margin-top: 20px;
        border-radius: 10px;
        box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);
      }
      .btn-light.text-danger {
        font-weight: bold;
        transition: all 0.3s;
      }
      .btn-light.text-danger:hover {
        color: #dc3545;
        background: #fff;
        border: 1px solid #dc3545;
      }
      ul.nav {
        margin-top: 20px;
      }
    </style>
  </head>
  <body>
    <div class="container-fluid">
      <div class="row">
        <!-- Sidebar -->
        <nav class="col-3 sidebar">
          <h4 class="text-center mb-4">Admin Property Store</h4>
          <ul class="nav flex-column">
            <li class="nav-item">
              <a href="<?= base_url('admin/dashboard')?>" class="nav-link active">Dashboard</a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('admin/daftar-property')?>" class="nav-link">Daftar Property Store</a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('admin/transaksi')?>" class="nav-link">Transaksi</a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('admin/pelanggan')?>" class="nav-link">Pelanggan</a>
            </li>
          </ul>
        </nav>

        <!-- Main Content -->
        <main class="col-9">
          <div class="header">
            <h2>Welcome, Admin Property Store</h2>
            <a href="<?= base_url('logout')?>" class="btn btn-light text-danger">Logout</a>
          </div>
          <div class="content">
            <?= $this->renderSection('main'); ?>
          </div>
        </main>
      </div>
    </div>

    <footer class="footer">
      <div class="container">
        Copyright 2024. Property Store . All rights reserved.
      </div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>